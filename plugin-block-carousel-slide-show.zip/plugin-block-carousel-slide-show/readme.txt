=== Carousel Block ===
Contributors: luiz0067yahoo
Tags: carousel, bootstrap, block, gutenberg, slider
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

WordPress Gutenberg Block for responsive Bootstrap 5 Carousels, compatible with any theme.

== Description ==

A modern and intuitive WordPress plugin that adds a native Gutenberg block for creating and managing responsive image carousels with Bootstrap 5 and Font Awesome 6 icons.

100% WYSIWYG (Visual Fidelity): What you see and edit in the block editor is exactly what is rendered in the preview and on the site's frontend.

== Installation ==

1. Download the plugin and upload the files to your WordPress plugins directory (`/wp-content/plugins/`).
2. In the WordPress administration panel, go to Plugins > Installed Plugins.
3. Locate Carousel Block for Bootstrap and click Activate.

== Changelog ==

= 1.0.0 =
* Initial release.
